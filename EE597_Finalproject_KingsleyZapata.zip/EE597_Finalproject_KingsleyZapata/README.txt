*** EE 597 Fall 2019 - Distributed Systems Project ***
Arshine Kingsley -- 3940957181
Santiago Zapata -- 3189193726

# Description
The project provides us with a scenario where UAVs have the mission of selecting targets within a common range. Our objective was to write an algorithm such that these targets were unique among the nodes. Our algorithm works on a simple premise,  we started by thinking on a mutual exclusion model so that only one node selects a target at a time. We later built on top of this, changing the procedure so that two nodes can take targets simultaneously, as long as they are different. A more comprehensive explanation of the code is provided on the report.


## Installation
The algorithm was written based on the original code, so to be able to run it you need to substitute the code in the original “track_target.py” file with our version. We are also providing a modified “start_tracking.sh” file. The original one was sending the output of all the nodes to the same log file (“track_n1.log”), we modified it so that each node has an individual log file. This of course is optional and does not need to be replaced for the algorithm to work.

## Usage
As we explained on the previous section, the code is built on top of the original one, so to run it you need to execute the same instructions.

==================Run the code=============================
	Terminal A:
	cd ~/Desktop/ee597/core/
	sudo service core-daemon start
	sudo core-gui --start ~/Desktop/ee597/uavs-targets/uav8-notrack.imn

	Terminal B:
	cd ~/Desktop/ee597/uavs-targets/
	bash start_tracking.sh udp
	bash start_testing.sh

=================Stop the code=============================
	Terminal A:
	ctrl+c
	sudo service core-daemon stop

	Terminal C:
	cd /tmp/
	sudo rm *.txt *.log


## Known bugs
We are aware of a couple of bugs.
1. Sometimes, when we start the tracking udp bash, we get an error saying that the network is not accessible. We were not able to replicate this bug consistently, and it is not something common, but we have the theory that it is responsibility of the emulator, as even if we are running the original code we see this errors. The output on the log files look like this:

=================Error output=============================

	Exception in thread Thread-1:
	Traceback (most recent call last):
		File "/usr/lib/python2.7/threading.py", line 801, in __bootstrap_inner
		  self.run()
		File "/home/san/Desktop/ee597/uavs-targets/track_target.py", line 54, in run
		  ReceiveUDP()
		File "/home/san/Desktop/ee597/uavs-targets/track_target.py", line 121, in ReceiveUDP
		  sk.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
		File "/usr/lib/python2.7/socket.py", line 228, in meth
		  return getattr(self._sock,name)(*args)
	error: [Errno 19] No such device

	Exception: copy waypoint from original position file. Ignore...
	Traceback (most recent call last):
		File "/home/san/Desktop/ee597/uavs-targets/track_target.py", line 377, in <module>
		  main()
		File "/home/san/Desktop/ee597/uavs-targets/track_target.py", line 370, in main
		  TrackTargets(args.covered_zone, args.track_range)
		File "/home/san/Desktop/ee597/uavs-targets/track_target.py", line 262, in TrackTargets
		  AdvertiseUDP(uavnode.nodeid, uavnode.trackid, uavnode.tkflagid, uavnode.disttrg) #san
		File "/home/san/Desktop/ee597/uavs-targets/track_target.py", line 105, in AdvertiseUDP
		  sk.sendto(buf, (addrinfo[4][0], port))
	socket.error: [Errno 101] Network is unreachable

* SOLUTION. We found out that by running the bash again right away, the model starts working fine, so you don’t have to worry too much about it.

2. We observed that some times during the test rounds, in between round when the nodes disappear and appear again, the color of the node is still the one for the previous round for a couple of seconds and then changes to gray. Sometimes even two nodes had the same color for a couple of seconds.

* SOLUTION. This apparently is not an issue of duplicate targets as the results showed that on all rounds the targets where unique, so we have the conclusion that it is only a visual issue and not an error on our code.

## Provided files

track_target.py - Contains the complete program to run our algorithm
start_tracking.sh - Our version of the shell, generates individual log output for the nodes
Under additional files:
	imgoutput - Resulting images from the tests, "orig" stands for original program, "imp" is our algorithm
	testoutput - Text results from the tests, "orig" stands for original program, "imp" is our algorithm 
	ratedata - The rate for every node on all the tests (only our algorithm results)
	networkbug - Log output of the error described on point 1 of known bugs
